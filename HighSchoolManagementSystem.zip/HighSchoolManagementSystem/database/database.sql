
CREATE DATABASE highschool_management;

USE highschool_management;

CREATE TABLE students(
    id INT PRIMARY KEY AUTO_INCREMENT,
    full_name VARCHAR(100),
    grade VARCHAR(20),
    section VARCHAR(20),
    phone VARCHAR(20)
);

CREATE TABLE teachers(
    id INT PRIMARY KEY AUTO_INCREMENT,
    full_name VARCHAR(100),
    subject VARCHAR(100),
    phone VARCHAR(20)
);

INSERT INTO students(full_name,grade,section,phone)
VALUES('Getnet Mulatu','11','A','0911111111');

INSERT INTO teachers(full_name,subject,phone)
VALUES('Abebe Kebede','Mathematics','0922222222');
