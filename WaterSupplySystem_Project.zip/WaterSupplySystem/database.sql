CREATE DATABASE water_supply_system;
USE water_supply_system;

CREATE TABLE users(
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50),
    password VARCHAR(50),
    role VARCHAR(20)
);

INSERT INTO users(username,password,role)
VALUES('admin','admin123','Admin');

CREATE TABLE customers(
    customer_id INT PRIMARY KEY AUTO_INCREMENT,
    full_name VARCHAR(100),
    phone VARCHAR(20),
    kebele VARCHAR(50),
    house_number VARCHAR(50),
    meter_number VARCHAR(50)
);