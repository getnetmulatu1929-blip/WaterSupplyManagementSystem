package dashboard;

import javax.swing.*;

public class Dashboard extends JFrame {

    public Dashboard() {

        setTitle("Dashboard");
        setSize(900,600);
        setLayout(null);
        setLocationRelativeTo(null);

        JLabel title = new JLabel("Welcome To Water Supply Dashboard");
        title.setBounds(200,100,500,40);
        add(title);

        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}