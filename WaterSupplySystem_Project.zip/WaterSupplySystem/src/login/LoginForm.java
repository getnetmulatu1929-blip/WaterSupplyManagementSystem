package login;

import dashboard.Dashboard;
import database.DBConnection;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class LoginForm extends JFrame implements ActionListener {

    JTextField userField;
    JPasswordField passField;
    JButton loginBtn;

    public LoginForm() {

        setTitle("Water Supply Management System");
        setSize(500,400);
        setLayout(null);
        setLocationRelativeTo(null);

        JLabel title = new JLabel("WATER SUPPLY MANAGEMENT SYSTEM");
        title.setBounds(50,40,400,40);
        title.setFont(new Font("Arial",Font.BOLD,20));
        add(title);

        JLabel user = new JLabel("Username");
        user.setBounds(80,120,100,30);
        add(user);

        userField = new JTextField();
        userField.setBounds(180,120,180,30);
        add(userField);

        JLabel pass = new JLabel("Password");
        pass.setBounds(80,180,100,30);
        add(pass);

        passField = new JPasswordField();
        passField.setBounds(180,180,180,30);
        add(passField);

        loginBtn = new JButton("Login");
        loginBtn.setBounds(180,260,120,40);
        add(loginBtn);

        loginBtn.addActionListener(this);

        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public void actionPerformed(ActionEvent e) {

        try {
            Connection con = DBConnection.getConnection();

            String sql = "SELECT * FROM users WHERE username=? AND password=?";

            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, userField.getText());
            ps.setString(2, passField.getText());

            ResultSet rs = ps.executeQuery();

            if(rs.next()) {
                JOptionPane.showMessageDialog(this,"Login Successful");
                dispose();
                new Dashboard();
            } else {
                JOptionPane.showMessageDialog(this,"Invalid Login");
            }

        } catch(Exception ex) {
            JOptionPane.showMessageDialog(this,ex);
        }
    }
}