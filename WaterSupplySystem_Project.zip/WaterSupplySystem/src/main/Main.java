package main;

import login.LoginForm;

public class Main {
    public static void main(String[] args) {
        new LoginForm();
    }
}